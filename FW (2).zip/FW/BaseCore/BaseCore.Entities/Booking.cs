// namespace BaseCore.Entities
// {
//     public class Booking
//     {
//         public int BookingID { get; set; }
//         public int TripID { get; set; }
//         public int? UserID { get; set; }
//         public string CustomerName { get; set; } = string.Empty;
//         public string CustomerPhone { get; set; } = string.Empty;
//         public string CustomerEmail { get; set; } = string.Empty;
//         public int TotalSeats { get; set; }
//         public decimal TotalPrice { get; set; }
//         public string PaymentMethod { get; set; } = string.Empty;
//         public string PaymentStatus { get; set; } = string.Empty;
//         public DateTime? BookingDate { get; set; }
//         public User? User { get; set; }

//         public Trip? Trip { get; set; }
//         public List<TicketSeat> TicketSeats { get; set; } = new();
//     }
// }
namespace BaseCore.Entities
{
    public class Booking
    {
        public int BookingID { get; set; }
        public int TripID { get; set; }
        public int? UserID { get; set; }
        public string? CustomerName { get; set; }    // ← thêm ?
        public string? CustomerPhone { get; set; }   // ← thêm ?
        public string? CustomerEmail { get; set; }   // ← thêm ?
        public int TotalSeats { get; set; }
        public decimal TotalPrice { get; set; }
        public string? PaymentMethod { get; set; }   // ← thêm ?
        public string? PaymentStatus { get; set; }   // ← thêm ?
        public DateTime? BookingDate { get; set; }
        public User? User { get; set; }
        public Trip? Trip { get; set; }
        public List<TicketSeat>? TicketSeats { get; set; }
    }
}