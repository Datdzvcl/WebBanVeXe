export const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:5001';
export const AUTH_API_BASE = import.meta.env.VITE_AUTH_API_BASE || 'http://localhost:5002';
export const AUTH_BASE = import.meta.env.VITE_AUTH_BASE || 'http://localhost:5002';
export function pick(obj, keys, fallback = '') {
  for (const key of keys) {
    if (obj && obj[key] !== undefined && obj[key] !== null) return obj[key];
  }
  return fallback;
}

export async function apiFetch(path, options = {}) {
  const token = localStorage.getItem('token');
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers || {}),
  };
  const res = await fetch(`${getApiBase(path)}${path}`, { ...options, headers });
  const text = await res.text();
  const data = text ? tryParseJson(text) : null;
  if (!res.ok) {
    const message = data?.message || data?.title || text || `API loi ${res.status}`;
    throw new Error(`${message} (${res.status})`);
  }
  return data;
}

function getApiBase(path) {
  if (path.startsWith('/api/auth') || path.startsWith('/api/users') || path.startsWith('/api/roles')) {
    return AUTH_API_BASE;
  }
  return API_BASE;
}

function tryParseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

export async function loginRequest(email, password) {
  const body = JSON.stringify({ email, Email: email, password, Password: password });
  return apiFetch('/api/auth/login', { method: 'POST', body });
}

export const normalizeUser = (data) => ({
  token: data?.token || data?.Token || '',
  userId: data?.userId || data?.UserId || data?.user?.id || data?.user?.userId || '',
  email: data?.email || data?.Email || data?.user?.email || '',
  fullName: data?.fullName || data?.FullName || data?.user?.fullName || data?.user?.name || '',
  role: data?.role || data?.Role || data?.user?.role || 'User',
});

export const isAdminRole = (role) => String(role || '').toLowerCase() === 'admin';

export const formatVND = (value) =>
  new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(Number(value || 0));

export function normalizeTrip(t) {
  const rawBus = t?.bus || t?.Bus || {};
  const rawOperator = rawBus?.operator || rawBus?.Operator || {};
  return {
    raw: t,
    id: pick(t, ['tripID', 'TripID', 'tripId', 'id', 'Id']),
    busId: Number(pick(t, ['busID', 'BusID', 'busId'], 0)),
    departureLocation: pick(t, ['departureLocation', 'DepartureLocation', 'fromLocation', 'FromLocation']),
    arrivalLocation: pick(t, ['arrivalLocation', 'ArrivalLocation', 'toLocation', 'ToLocation']),
    departureTime: pick(t, ['departureTime', 'DepartureTime']),
    arrivalTime: pick(t, ['arrivalTime', 'ArrivalTime']),
    operator: pick(t, ['operator', 'Operator', 'operatorName', 'OperatorName', 'busOperator', 'BusOperator', 'companyName', 'CompanyName'], pick(rawOperator, ['name', 'Name'])),
    busType: pick(t, ['busType', 'BusType', 'type', 'Type'], pick(rawBus, ['busType', 'BusType'])),
    price: Number(pick(t, ['price', 'Price'], 0)),
    availableSeats: Number(pick(t, ['availableSeats', 'AvailableSeats'], 0)),
    status: pick(t, ['status', 'Status'], ''),
  };
}
