// // import { Link, useNavigate } from 'react-router-dom';
// // import { useState } from 'react';
// // import { Link, useNavigate } from 'react-router-dom';
// // export default function Navbar({ simple = false }) {
// //   const navigate = useNavigate();
// //   const token = localStorage.getItem('token');
// //   const user = JSON.parse(localStorage.getItem('user') || 'null');

// //   const logout = () => {
// //     localStorage.removeItem('token');
// //     localStorage.removeItem('user');
// //     navigate('/');
// //     window.location.reload();
// //   };

// //   return (
// //     <nav className="navbar">
// //       <div className="container">
// //         <Link to="/" className="logo"><i className="fa-solid fa-bus" /> VéXeAZ</Link>
// //         {!simple && (
// //           <>
// //             <div className="nav-links">
// //               <Link to="/">Trang chủ</Link>
// //               <a href="/#about">Giới thiệu</a>
// //               <Link to="/search">Tìm chuyến</Link>
// //               <a href="/#contact">Liên hệ</a>
// //             </div>
// //             <div className="nav-actions">
// //               {token && user ? (
// //                 <>
// //                   {/* <span className="btn btn-outline"><i className="fa-solid fa-user" /> {user.fullName}</span> */}
// //                   {user.role === 'Admin' || user.role === 'admin'
// //                     ? <Link to="/admin" className="btn btn-outline"><i className="fa-solid fa-user" /> {user.fullName}</Link>
// //                     : <span className="btn btn-outline"><i className="fa-solid fa-user" /> {user.fullName}</span>
// //                   }
// //                   <button className="btn btn-outline logout-btn" onClick={logout}>Đăng xuất</button>
// //                 </>
// //               ) : (
// //                 <>
// //                   <Link to="/login" className="btn btn-outline">Đăng nhập</Link>
// //                   <Link to="/register" className="btn btn-primary">Đăng ký</Link>
// //                 </>
// //               )}
// //             </div>
// //           </>
// //         )}
// //       </div>
// //     </nav>
// //   );
// // }
// import { Link, useNavigate } from 'react-router-dom';
// import { useState } from 'react';

// export default function Navbar({ simple = false }) {
//   const navigate = useNavigate();
//   const token = localStorage.getItem('token');
//   const user = JSON.parse(localStorage.getItem('user') || 'null');

//   const [showMenu, setShowMenu] = useState(false);

//   const logout = () => {
//     localStorage.removeItem('token');
//     localStorage.removeItem('user');
//     navigate('/');
//     window.location.reload();
//   };

//   return (
//     <nav className="navbar">
//       <div className="container">
//         <Link to="/" className="logo">
//           <i className="fa-solid fa-bus" /> VéXeAZ
//         </Link>

//         {!simple && (
//           <>
//             <div className="nav-links">
//               <Link to="/">Trang chủ</Link>
//               <a href="/#about">Giới thiệu</a>
//               <Link to="/search">Tìm chuyến</Link>
//               <a href="/#contact">Liên hệ</a>
//             </div>

//             <div className="nav-actions">

//               {/* ===== CODE CŨ (ĐÃ COMMENT CHUẨN - KHÔNG LỖI) ===== */}
//               {/*
//               {token && user ? (
//                 <>
//                   {user.role === 'Admin' || user.role === 'admin' ? (
//                     <Link to="/admin" className="btn btn-outline">
//                       <i className="fa-solid fa-user" /> {user.fullName}
//                     </Link>
//                   ) : (
//                     <span className="btn btn-outline">
//                       <i className="fa-solid fa-user" /> {user.fullName}
//                     </span>
//                   )}
//                   <button className="btn btn-outline logout-btn" onClick={logout}>
//                     Đăng xuất
//                   </button>
//                 </>
//               ) : (
//                 <>
//                   <Link to="/login" className="btn btn-outline">Đăng nhập</Link>
//                   <Link to="/register" className="btn btn-primary">Đăng ký</Link>
//                 </>
//               )}
//               */}

//               {/* ===== CODE MỚI DROPDOWN ===== */}
//               {token && user ? (
//                 <div style={{ position: 'relative' }}>
//                   <button
//                     className="btn btn-outline"
//                     onClick={() => setShowMenu(!showMenu)}
//                     style={{ display: 'flex', alignItems: 'center', gap: 6 }}
//                   >
//                     <i className="fa-solid fa-user" /> {user.fullName}
//                     <i
//                       className={`fa-solid fa-chevron-${showMenu ? 'up' : 'down'}`}
//                       style={{ fontSize: 12 }}
//                     />
//                   </button>

//                   {showMenu && (
//                     <div
//                       style={{
//                         position: 'absolute',
//                         right: 0,
//                         top: '110%',
//                         background: 'white',
//                         borderRadius: 10,
//                         boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
//                         minWidth: 200,
//                         zIndex: 999,
//                         overflow: 'hidden'
//                       }}
//                     >
//                       <div style={{ padding: '12px 16px', borderBottom: '1px solid #f0f0f0' }}>
//                         <div style={{ fontWeight: 600 }}>{user.fullName}</div>
//                         <div style={{ fontSize: 13, color: '#666' }}>{user.email}</div>
//                       </div>

//                       {/* <Link to="/profile" className="dropdown-item">Thông tin cá nhân</Link>
//                       <Link to="/my-tickets" className="dropdown-item">Vé của tôi</Link>
//                       <Link to="/change-password" className="dropdown-item">Đổi mật khẩu</Link>

//                       <button onClick={logout} className="dropdown-item logout">
//                         Đăng xuất
//                       </button> */}
//                       <Link to="/profile" className="dropdown-item">
//                       <i className="fa-solid fa-user-pen" style={{width:16,marginRight:8,color:'#2563eb'}}/> Thông tin cá nhân
//                     </Link>
//                     <Link to="/my-tickets" className="dropdown-item">
//                       <i className="fa-solid fa-ticket" style={{width:16,marginRight:8,color:'#16a34a'}}/> Vé của tôi
//                     </Link>
//                     <Link to="/change-password" className="dropdown-item">
//                       <i className="fa-solid fa-lock" style={{width:16,marginRight:8,color:'#9333ea'}}/> Đổi mật khẩu
//                     </Link>
//                     <button onClick={logout} className="dropdown-item logout">
//                       <i className="fa-solid fa-right-from-bracket" style={{width:16,marginRight:8}}/> Đăng xuất
//                     </button>
//                     </div>
//                   )}
//                 </div>
//               ) : (
//                 <>
//                   <Link to="/login" className="btn btn-outline">Đăng nhập</Link>
//                   <Link to="/register" className="btn btn-primary">Đăng ký</Link>
//                 </>
//               )}

//             </div>
//           </>
//         )}
//       </div>
//     </nav>
//   );
// }

import { Link, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";

export default function Navbar({ simple = false }) {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user") || "null");

  const [showMenu, setShowMenu] = useState(false);

  const isAdmin = user?.role === "Admin" || user?.role === "admin";

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/");
    window.location.reload();
  };

  // 👉 đóng dropdown khi click ra ngoài
  useEffect(() => {
    const handleClick = (e) => {
      if (!e.target.closest(".nav-actions")) {
        setShowMenu(false);
      }
    };
    document.addEventListener("click", handleClick);
    return () => document.removeEventListener("click", handleClick);
  }, []);

  return (
    <nav className="navbar">
      <div className="container">
        <Link to="/" className="logo">
          <i className="fa-solid fa-bus" /> VéXeAZ
        </Link>

        {!simple && (
          <>
            <div className="nav-links">
              <Link to="/">Trang chủ</Link>
              <a href="/#about">Giới thiệu</a>
              {/* <Link to="/search">Tìm chuyến</Link> */}
              <a href="/#contact">Liên hệ</a>
            </div>

            <div className="nav-actions">
              {/* ===== CODE CŨ (ĐÃ COMMENT - OK) ===== */}
              {/*
              {token && user ? (
                <>
                  {user.role === 'Admin' || user.role === 'admin' ? (
                    <Link to="/admin" className="btn btn-outline">
                      <i className="fa-solid fa-user" /> {user.fullName}
                    </Link>
                  ) : (
                    <span className="btn btn-outline">
                      <i className="fa-solid fa-user" /> {user.fullName}
                    </span>
                  )}
                  <button className="btn btn-outline logout-btn" onClick={logout}>
                    Đăng xuất
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login" className="btn btn-outline">Đăng nhập</Link>
                  <Link to="/register" className="btn btn-primary">Đăng ký</Link>
                </>
              )}
              */}

              {/* ===== DROPDOWN ===== */}
              {token && user ? (
                <div style={{ position: "relative" }}>
                  {/* BUTTON */}
                  <button
                    className="btn btn-outline"
                    onClick={() => setShowMenu(!showMenu)}
                    style={{ display: "flex", alignItems: "center", gap: 6 }}
                  >
                    <i className="fa-solid fa-user" /> {user.fullName}
                    <i
                      className={`fa-solid fa-chevron-${showMenu ? "up" : "down"}`}
                      style={{ fontSize: 12 }}
                    />
                  </button>

                  {/* MENU */}
                  {showMenu && (
                    <div
                      style={{
                        position: "absolute",
                        right: 0,
                        top: "110%",
                        background: "white",
                        borderRadius: 10,
                        boxShadow: "0 4px 20px rgba(0,0,0,0.15)",
                        minWidth: 200,
                        zIndex: 999,
                        overflow: "hidden",
                      }}
                    >
                      <div
                        style={{
                          padding: "12px 16px",
                          borderBottom: "1px solid #f0f0f0",
                        }}
                      >
                        <div style={{ fontWeight: 600 }}>{user.fullName}</div>
                        <div style={{ fontSize: 13, color: "#666" }}>
                          {user.email}
                        </div>
                      </div>

                      <Link to="/profile" className="dropdown-item">
                        <i
                          className="fa-solid fa-user-pen"
                          style={{
                            width: 16,
                            marginRight: 8,
                            color: "#2563eb",
                          }}
                        />
                        Thông tin cá nhân
                      </Link>

                      <Link to="/my-tickets" className="dropdown-item">
                        <i
                          className="fa-solid fa-ticket"
                          style={{
                            width: 16,
                            marginRight: 8,
                            color: "#16a34a",
                          }}
                        />
                        Vé của tôi
                      </Link>

                      <Link to="/change-password" className="dropdown-item">
                        <i
                          className="fa-solid fa-lock"
                          style={{
                            width: 16,
                            marginRight: 8,
                            color: "#9333ea",
                          }}
                        />
                        Đổi mật khẩu
                      </Link>

                      {/* 🔥 ADMIN ONLY */}
                      {isAdmin && (
                        <Link to="/admin" className="dropdown-item">
                          <i
                            className="fa-solid fa-gear"
                            style={{
                              width: 16,
                              marginRight: 8,
                              color: "#f59e0b",
                            }}
                          />
                          Quản trị trang
                        </Link>
                      )}

                      <button onClick={logout} className="dropdown-item logout">
                        <i
                          className="fa-solid fa-right-from-bracket"
                          style={{ width: 16, marginRight: 8 }}
                        />
                        Đăng xuất
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <>
                  <Link to="/login" className="btn btn-outline">
                    Đăng nhập
                  </Link>
                  <Link to="/register" className="btn btn-primary">
                    Đăng ký
                  </Link>
                </>
              )}
            </div>
          </>
        )}
      </div>
    </nav>
  );
}
