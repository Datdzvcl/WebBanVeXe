export default function Footer() {
  return (
    <footer className="footer" id="contact">
      <div className="container footer-content">
        <div className="footer-col">
          <h3>VéXeAZ</h3>
          <p>Nền tảng đặt vé xe khách trực tuyến cao cấp hàng đầu Việt Nam.</p>
        </div>
        <div className="footer-col">
          <h3>Liên Kết</h3>
          <a href="/#about">Về chúng tôi</a>
          <a href="#">Nhà xe đối tác</a>
          <a href="#">Hình thức thanh toán</a>
        </div>
        <div className="footer-col">
          <h3>Hỗ Trợ</h3>
          <a href="#">Hướng dẫn đặt vé</a>
          <a href="#">Chính sách hoàn tiền</a>
          <a href="#">Câu hỏi thường gặp</a>
        </div>
      </div>
      <div className="footer-bottom text-center">
        <p>&copy; 2026 VéXeAZ. All rights reserved.</p>
      </div>
    </footer>
  );
}
