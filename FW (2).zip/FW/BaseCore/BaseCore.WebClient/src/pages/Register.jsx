import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { apiFetch } from '../api';

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ fullName: '', email: '', phone: '', password: '', confirmPassword: '' });
  const submit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) return alert('Mật khẩu xác nhận không khớp.');
    try {
      await apiFetch('/api/auth/register', { method: 'POST', body: JSON.stringify({ fullName: form.fullName, email: form.email, phone: form.phone, password: form.password }) });
      alert('Đăng ký thành công. Vui lòng đăng nhập.');
      navigate('/login');
    } catch (err) { alert(err.message || 'Đăng ký thất bại'); }
  };
  const set = (k, v) => setForm({ ...form, [k]: v });
  return <><Navbar simple /><div className="auth-wrap"><div className="auth-card"><div className="auth-title"><h2><i className="fa-solid fa-bus" /> VéXeAZ</h2><p>Tạo tài khoản mới</p></div><form onSubmit={submit}>{[['fullName','Họ và tên','text'],['email','Email','email'],['phone','Số điện thoại','tel'],['password','Mật khẩu','password'],['confirmPassword','Xác nhận mật khẩu','password']].map(([k, label, type]) => <div className="form-group" key={k}><label>{label}</label><input type={type} value={form[k]} onChange={e => set(k, e.target.value)} required /></div>)}<button className="btn btn-primary auth-btn">Đăng Ký Ngay</button></form><p className="auth-bottom">Đã có tài khoản? <Link to="/login">Đăng nhập</Link></p></div></div></>;
}
