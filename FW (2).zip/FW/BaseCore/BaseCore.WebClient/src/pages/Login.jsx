import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { loginRequest, normalizeUser, isAdminRole } from '../api';

export default function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await loginRequest(form.email.trim(), form.password);
      const user = normalizeUser(data);
      if (!user.token) throw new Error('API đăng nhập không trả về token.');
      localStorage.setItem('token', user.token);
      localStorage.setItem('user', JSON.stringify(user));
      navigate(isAdminRole(user.role) ? '/admin' : '/', { replace: true });
    } catch (err) {
      alert(err.message || 'Đăng nhập thất bại. Kiểm tra email/mật khẩu và backend AuthService.');
    } finally {
      setLoading(false);
    }
  };

  return <><Navbar simple /><div className="auth-wrap"><div className="auth-card"><div className="auth-title"><h2><i className="fa-solid fa-bus" /> VéXeAZ</h2><p>Đăng nhập để tiếp tục</p></div><form onSubmit={submit}><div className="form-group"><label>Email</label><input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="admin@example.com" required /></div><div className="form-group"><label>Mật khẩu</label><input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required /></div><div className="auth-row"><label><input type="checkbox" /> Nhớ mật khẩu</label><a href="#">Quên mật khẩu?</a></div><button disabled={loading} className="btn btn-primary auth-btn">{loading ? 'Đang đăng nhập...' : 'Đăng Nhập'}</button></form><p className="auth-bottom">Chưa có tài khoản? <Link to="/register">Đăng ký ngay</Link></p></div></div></>;
}
