﻿using BaseCore.Common;
using BaseCore.Entities;
using BaseCore.Repository.Authen;

namespace BaseCore.Services.Authen
{
    public interface IUserService
    {
        Task<User?> Authenticate(string email, string password);
        Task<List<User>> GetAll();
        Task<User?> GetById(int id);
        Task<User> Create(User user, string password);
        Task Update(User user, string? password = null);
        Task Delete(int id);
        Task<(List<User> Users, int TotalCount)> Search(string keyword, int page, int pageSize);
    }

    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<User?> Authenticate(string email, string password)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
                return null;

            var user = await _userRepository.GetByUsernameAsync(email);

            if (user == null)
                return null;

            // Tạm thời so sánh password đã hash theo TokenHelper
            var hashedInputPassword = TokenHelper.HashPassword(password, out byte[] salt);

            // Nếu login admin123 không được, xem ghi chú bên dưới
            if (user.PasswordHash != hashedInputPassword && user.PasswordHash != password)
                return null;

            return user;
        }

        public async Task<List<User>> GetAll()
        {
            return await _userRepository.GetAllAsync();
        }

        public async Task<User?> GetById(int id)
        {
            return await _userRepository.GetByIdAsync(id);
        }

        public async Task<User> Create(User user, string password)
        {
            user.PasswordHash = password;
            user.CreatedAt ??= DateTime.Now;

            await _userRepository.CreateAsync(user);
            return user;
        }

        public async Task Update(User user, string? password = null)
        {
            if (!string.IsNullOrEmpty(password))
            {
                user.PasswordHash = password;
            }

            await _userRepository.UpdateAsync(user);
        }

        public async Task Delete(int id)
        {
            await _userRepository.DeleteAsync(id);
        }

        public async Task<(List<User> Users, int TotalCount)> Search(string keyword, int page, int pageSize)
        {
            return await _userRepository.SearchAsync(keyword, page, pageSize);
        }
    }
}