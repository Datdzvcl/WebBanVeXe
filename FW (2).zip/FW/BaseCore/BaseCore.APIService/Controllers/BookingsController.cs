using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BaseCore.Entities;
using BaseCore.Repository;

namespace BaseCore.APIService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingsController : ControllerBase
    {
        private readonly MySqlDbContext _context;

        public BookingsController(MySqlDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var bookings = await _context.Bookings
                .OrderByDescending(x => x.BookingDate)
                .ToListAsync();

            return Ok(bookings);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var booking = await _context.Bookings
                .Where(x => x.BookingID == id)
                .Select(x => new
                {
                    x.BookingID,
                    x.TripID,
                    x.UserID,
                    x.CustomerName,
                    x.CustomerPhone,
                    x.CustomerEmail,
                    x.TotalSeats,
                    x.TotalPrice,
                    x.PaymentMethod,
                    x.PaymentStatus,
                    x.BookingDate
                })
                .FirstOrDefaultAsync();

            if (booking == null)
                return NotFound();

            return Ok(booking);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Booking booking)
        {
            var trip = await _context.Trips.FindAsync(booking.TripID);

            if (trip == null)
                return BadRequest("Không tìm thấy chuyến xe");

            if (trip.AvailableSeats < booking.TotalSeats)
                return BadRequest("Không đủ ghế trống");

            booking.BookingDate = DateTime.Now;

            if (string.IsNullOrWhiteSpace(booking.PaymentStatus))
                booking.PaymentStatus = "Pending";

            _context.Bookings.Add(booking);
            trip.AvailableSeats -= booking.TotalSeats;

            await _context.SaveChangesAsync();

            return Ok(new
            {
                booking.BookingID,
                booking.TripID,
                booking.UserID,
                booking.CustomerName,
                booking.CustomerPhone,
                booking.CustomerEmail,
                booking.TotalSeats,
                booking.TotalPrice,
                booking.PaymentMethod,
                booking.PaymentStatus,
                booking.BookingDate
            });
        }

        [HttpPut("{id}/payment-status")]
        public async Task<IActionResult> UpdatePaymentStatus(int id, [FromBody] string status)
        {
            var booking = await _context.Bookings.FindAsync(id);

            if (booking == null)
                return NotFound();

            booking.PaymentStatus = status;
            await _context.SaveChangesAsync();

            return Ok(new { booking.BookingID, booking.PaymentStatus });
        }

        /// <summary>
        /// Hủy vé: đổi PaymentStatus = "Cancelled" và hoàn lại AvailableSeats cho chuyến xe.
        /// </summary>
        [HttpPut("{id}/cancel")]
        public async Task<IActionResult> Cancel(int id)
        {
            var booking = await _context.Bookings
                .Include(b => b.Trip)
                .FirstOrDefaultAsync(b => b.BookingID == id);

            if (booking == null)
                return NotFound();

            if (booking.PaymentStatus == "Cancelled")
                return BadRequest("Vé này đã bị hủy trước đó.");

            if (booking.PaymentStatus == "Paid")
                return BadRequest("Vé đã thanh toán, không thể hủy tại đây. Vui lòng liên hệ nhà xe.");

            // Hoàn ghế về cho chuyến xe
            if (booking.Trip != null)
                booking.Trip.AvailableSeats += booking.TotalSeats;

            booking.PaymentStatus = "Cancelled";

            await _context.SaveChangesAsync();

            return Ok(new
            {
                booking.BookingID,
                booking.PaymentStatus,
                SeatsRestored = booking.TotalSeats
            });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var booking = await _context.Bookings.FindAsync(id);

            if (booking == null)
                return NotFound();

            // Xóa TicketSeats liên quan trước
            var ticketSeats = await _context.TicketSeats
                .Where(t => t.BookingID == id)
                .ToListAsync();

            if (ticketSeats.Any())
                _context.TicketSeats.RemoveRange(ticketSeats);

            // Hoàn lại ghế cho chuyến xe
            var trip = await _context.Trips.FindAsync(booking.TripID);
            if (trip != null)
                trip.AvailableSeats += booking.TotalSeats;

            _context.Bookings.Remove(booking);
            await _context.SaveChangesAsync();

            return Ok();
        }
    }
}
