﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BaseCore.Entities;
using BaseCore.Repository;

namespace BaseCore.APIService.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class BusesController : ControllerBase
	{
		private readonly MySqlDbContext _context;

		public BusesController(MySqlDbContext context)
		{
			_context = context;
		}

		[HttpGet]
		public async Task<IActionResult> GetAll()
		{
			return Ok(await _context.Buses.ToListAsync());
		}

		[HttpGet("{id}")]
		public async Task<IActionResult> GetById(int id)
		{
			var bus = await _context.Buses.FindAsync(id);

			if (bus == null)
				return NotFound();

			return Ok(bus);
		}

		[HttpPost]
		public async Task<IActionResult> Create(Bus bus)
		{
			_context.Buses.Add(bus);
			await _context.SaveChangesAsync();

			return Ok(bus);
		}

		[HttpPut("{id}")]
		public async Task<IActionResult> Update(int id, Bus bus)
		{
			if (id != bus.BusID)
				return BadRequest("ID không khớp");

			_context.Entry(bus).State = EntityState.Modified;
			await _context.SaveChangesAsync();

			return Ok(bus);
		}

		[HttpDelete("{id}")]
		public async Task<IActionResult> Delete(int id)
		{
			var bus = await _context.Buses.FindAsync(id);

			if (bus == null)
				return NotFound();

			_context.Buses.Remove(bus);
			await _context.SaveChangesAsync();

			return Ok();
		}
	}
}