using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BaseCore.Entities;
using BaseCore.Repository;

namespace BaseCore.APIService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OperatorsController : ControllerBase
    {
        private readonly MySqlDbContext _context;

        public OperatorsController(MySqlDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _context.Operators.ToListAsync());
        }

        [HttpPost]
        public async Task<IActionResult> Create(Operator item)
        {
            _context.Operators.Add(item);
            await _context.SaveChangesAsync();

            return Ok(item);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Operator item)
        {
            if (id != item.OperatorID)
                return BadRequest("ID không khớp");

            _context.Entry(item).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return Ok(item);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _context.Operators.FindAsync(id);

            if (item == null)
                return NotFound();

            _context.Operators.Remove(item);
            await _context.SaveChangesAsync();

            return Ok();
        }
    }
}