using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BaseCore.Entities;
using BaseCore.Repository;

namespace BaseCore.APIService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TripsController : ControllerBase
    {
        private readonly MySqlDbContext _context;

        public TripsController(MySqlDbContext context)
        {
            _context = context;
        }

        // GET /api/trips?page=1&pageSize=20
        [HttpGet]
        public async Task<IActionResult> GetAll(
            [FromQuery] int page     = 1,
            [FromQuery] int pageSize = 20)
        {
            pageSize = Math.Clamp(pageSize, 1, 100);
            page     = Math.Max(page, 1);

            var query = _context.Trips
                .Include(x => x.Bus).ThenInclude(x => x.Operator)
                .OrderBy(x => x.DepartureTime);

            var total = await query.CountAsync();

            var trips = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(x => new
                {
                    x.TripID,
                    x.BusID,
                    x.DepartureLocation,
                    x.ArrivalLocation,
                    x.DepartureTime,
                    x.ArrivalTime,
                    x.Price,
                    x.AvailableSeats,
                    x.Status,
                    BusType      = x.Bus != null ? x.Bus.BusType      : null,
                    OperatorName = x.Bus != null && x.Bus.Operator != null ? x.Bus.Operator.Name : null
                })
                .ToListAsync();

            return Ok(new
            {
                data       = trips,
                page,
                pageSize,
                total,
                totalPages = (int)Math.Ceiling((double)total / pageSize)
            });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var trip = await _context.Trips
                .Include(x => x.Bus).ThenInclude(x => x.Operator)
                .Where(x => x.TripID == id)
                .Select(x => new
                {
                    x.TripID,
                    x.BusID,
                    x.DepartureLocation,
                    x.ArrivalLocation,
                    x.DepartureTime,
                    x.ArrivalTime,
                    x.Price,
                    x.AvailableSeats,
                    x.Status,
                    BusType      = x.Bus != null ? x.Bus.BusType      : null,
                    OperatorName = x.Bus != null && x.Bus.Operator != null ? x.Bus.Operator.Name : null
                })
                .FirstOrDefaultAsync();

            if (trip == null)
                return NotFound();

            return Ok(trip);
        }

        // GET /api/trips/search?from=HN&to=DN&date=2025-06-10&page=1&pageSize=20
        [HttpGet("search")]
        public async Task<IActionResult> Search(
            [FromQuery] string?   from,
            [FromQuery] string?   to,
            [FromQuery] DateTime? date,
            [FromQuery] int       page     = 1,
            [FromQuery] int       pageSize = 20)
        {
            pageSize = Math.Clamp(pageSize, 1, 100);
            page     = Math.Max(page, 1);

            var query = _context.Trips
                .Include(x => x.Bus).ThenInclude(x => x.Operator)
                .Where(x => x.AvailableSeats > 0);

            if (!string.IsNullOrWhiteSpace(from))
                query = query.Where(x => x.DepartureLocation.Contains(from));

            if (!string.IsNullOrWhiteSpace(to))
                query = query.Where(x => x.ArrivalLocation.Contains(to));

            // Lọc từ ngày đó trở đi
            if (date.HasValue)
                query = query.Where(x => x.DepartureTime.Date >= date.Value.Date);

            var total = await query.CountAsync();

            var trips = await query
                .OrderBy(x => x.DepartureTime)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(x => new
                {
                    x.TripID,
                    x.BusID,
                    x.DepartureLocation,
                    x.ArrivalLocation,
                    x.DepartureTime,
                    x.ArrivalTime,
                    x.Price,
                    x.AvailableSeats,
                    x.Status,
                    BusType      = x.Bus != null ? x.Bus.BusType      : null,
                    OperatorName = x.Bus != null && x.Bus.Operator != null ? x.Bus.Operator.Name : null
                })
                .ToListAsync();

            return Ok(new
            {
                data       = trips,
                page,
                pageSize,
                total,
                totalPages = (int)Math.Ceiling((double)total / pageSize)
            });
        }

        [HttpPost]
        public async Task<IActionResult> Create(Trip trip)
        {
            trip.Status = NormalizeStatus(trip.Status);
            _context.Trips.Add(trip);
            await _context.SaveChangesAsync();
            return Ok(trip);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Trip trip)
        {
            if (id != trip.TripID)
                return BadRequest("ID không khớp");

            trip.Status = NormalizeStatus(trip.Status);
            _context.Entry(trip).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return Ok(trip);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var trip = await _context.Trips.FindAsync(id);
            if (trip == null) return NotFound();

            _context.Trips.Remove(trip);
            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpGet("locations")]
        public async Task<IActionResult> GetLocations()
        {
            var departures = await _context.Trips.Select(x => x.DepartureLocation).Distinct().ToListAsync();
            var arrivals   = await _context.Trips.Select(x => x.ArrivalLocation).Distinct().ToListAsync();
            var all        = departures.Union(arrivals)
                .Where(x => !string.IsNullOrEmpty(x))
                .OrderBy(x => x)
                .ToList();
            return Ok(all);
        }

        private static string NormalizeStatus(string? status)
        {
            var value = (status ?? string.Empty).Trim();
            return value.ToLowerInvariant() switch
            {
                "active"    => "Scheduled",
                "scheduled" => "Scheduled",
                "on-going"  => "On-going",
                "ongoing"   => "On-going",
                "completed" => "Completed",
                _           => "Scheduled"
            };
        }
    }
}
