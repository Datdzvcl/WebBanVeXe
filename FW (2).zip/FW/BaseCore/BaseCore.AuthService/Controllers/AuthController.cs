using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using BaseCore.Common;
using BaseCore.Services.Authen;
using System.Threading.Tasks;

namespace BaseCore.AuthService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly string _secretKey;
        private const int TokenExpirationMinutes = 480;

        public AuthController(IUserService userService, IConfiguration configuration)
        {
            _userService = userService;
            _secretKey = configuration["Jwt:SecretKey"]
                ?? configuration["AppSettings:Secret"]
                ?? "YourSecretKeyForAuthenticationShouldBeLongEnough";
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            if (request == null ||
                string.IsNullOrEmpty(request.Email) ||
                string.IsNullOrEmpty(request.Password))
            {
                return BadRequest(new { message = "Email and password are required" });
            }

            var user = await _userService.Authenticate(request.Email, request.Password);

            if (user == null)
                return Unauthorized(new { message = "Invalid email or password" });

            var role = user.Role ?? "User";

            var token = TokenHelper.GenerateToken(
                _secretKey,
                TokenExpirationMinutes,
                user.UserID.ToString(),
                user.Email,
                role
            );

            return Ok(new LoginResponse
            {
                Token = token,
                UserId = user.UserID.ToString(),
                Email = user.Email,
                FullName = user.FullName,
                Role = role,
                ExpiresIn = TokenExpirationMinutes * 60
            });
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest request)
        {
            if (request == null)
                return BadRequest(new { message = "Invalid request" });

            if (string.IsNullOrEmpty(request.Email) || string.IsNullOrEmpty(request.Password))
                return BadRequest(new { message = "Email and password are required" });

            if (request.Password.Length < 6)
                return BadRequest(new { message = "Password must be at least 6 characters" });

            try
            {
                var user = new BaseCore.Entities.User
                {
                    FullName = request.FullName ?? request.Email,
                    Email = request.Email,
                    Phone = request.Phone,
                    Role = "User",
                    CreatedAt = DateTime.Now
                };

                var createdUser = await _userService.Create(user, request.Password);

                return Ok(new
                {
                    message = "Registration successful",
                    userId = createdUser.UserID
                });
            }
            catch (System.Exception ex)
            {
                return BadRequest(new { message = "Registration failed: " + ex.Message });
            }
        }
    }

    public class LoginRequest
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class LoginResponse
    {
        public string Token { get; set; }
        public string UserId { get; set; }
        public string Email { get; set; }
        public string FullName { get; set; }
        public string Role { get; set; }
        public int ExpiresIn { get; set; }
    }

    public class RegisterRequest
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string FullName { get; set; }
        public string Phone { get; set; }
    }
}